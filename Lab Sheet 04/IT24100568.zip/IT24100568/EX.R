setwd("C:/Users/it24100568/Desktop/IT24100568")
branch_data <- read.table("Exercise.txt", header = TRUE, sep = ", ")
#Q3
boxplot (branch_data$Sales_X1, main="boxplot for sales distribution", horizontal=TRUE)

#Q4
summary(branch_data$Advertising_X2)

#Q5

find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR <- Q3 - Q1
  l_b <- Q1 - 1.5 * IQR
  u_b <- Q3 + 1.5 * IQR
  
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}

get_outliers(branch_data$Years_X3)
